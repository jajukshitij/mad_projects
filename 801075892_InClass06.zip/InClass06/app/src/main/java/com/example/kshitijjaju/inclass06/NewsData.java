package com.example.kshitijjaju.inclass06;

public class NewsData {
    String title,date,imageUrl,decscription;

    @Override
    public String toString() {
        return "NewsData{" +
                "title='" + title + '\'' +
                ", date='" + date + '\'' +
                ", imageUrl='" + imageUrl + '\'' +
                ", decscription='" + decscription + '\'' +
                '}';
    }
}
