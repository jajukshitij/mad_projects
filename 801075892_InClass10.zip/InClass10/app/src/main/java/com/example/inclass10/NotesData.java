package com.example.inclass10;

public class NotesData {
    String id, userId, text, v;

    @Override
    public String toString() {
        return "NotesData{" +
                "id='" + id + '\'' +
                ", userId='" + userId + '\'' +
                ", text='" + text + '\'' +
                ", v='" + v + '\'' +
                '}';
    }
}
